package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class FindBook extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	HttpSession session=request.getSession(false); 
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	String bookid = request.getParameter("bookid");
	out.println("<html>");
	out.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");
	StudentExpert se= new StudentExpert();
	
	try
		{
			
				Book s=new Book();
			
				s=se.BookDetails(bookid);
				if(s.bookid==""){
				out.println("<h3>Enter valid Book id</h3>");
			}
			else{
				out.println("<h3>BOOK DETAILS</h3>");
				out.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
				out.println("<tr>");
				out.println("<th>BOOK ID</th>");
				out.println("<th>BOOK NAME</th>");
				out.println("<th>AUTHOR</th>");
				out.println("<th>YEAR OF PUBLISH</th>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<td>"+s.bookid+"</td>");
				out.println("<td>"+s.bookname+"</td>");
				out.println("<td>"+s.author+"</td>");
				out.println("<td>"+s.yop+"</td>");
				out.println("</tr>");
				out.println("</table>");
			}

				
			
			

		}
		catch(Exception E)
		{
			System.out.println(E);
		}
	out.println("</div>");
	out.println("</body>");
	out.println("</html>");

}
}