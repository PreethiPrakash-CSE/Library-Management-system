package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class RemoveBook extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	HttpSession session=request.getSession(false);
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	String bookid = request.getParameter("bookid");
	LibrarianExpert le=new LibrarianExpert();
	String result="";

	out.println("<html>");
	out.println("<head><style>#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");
	
	
	try
	{
	result=le.FindBook(bookid);

	}
	catch(Exception E)
	{
	System.out.println(E);
	}
	
	if(result.equals("invalid"))
	{
		try
		{
		le.removeBook(bookid);
		out.println("<h3>BOOK DELETED</h3>");
		}
		catch(Exception E)
		{
		System.out.println(E);
		}
	}
	else
	{
		out.println("<h3>BOOK DOESN'T EXISTS, CANNOT BE DELETED</h3>");
	}

	out.println("</div>");
	out.println("</body>");
	out.println("</html>");


}

}