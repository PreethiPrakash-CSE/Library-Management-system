package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Teacher
{
	public String userid;
	public String name;
	public String password;
	public String dept;
	
}