package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class Search extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{

	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	out.println("<html>");
	out.println("<head><style>#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");
	out.println("<form action='schid' method='post'><br>");
	out.println("<input type='submit' value='Search by id'>");			
	out.println("</form>");
	out.println("<form action='schyear' method='post'><br>");
	out.println("<input type='submit' value='Search by year'>");
	out.println("</form>");
	out.println("<form action='schauth' method='post'><br>");
	out.println("<input type='submit' value='Search by author'>");			
	out.println("</form>");
	out.println("</div>");
	out.println("</body>");
	out.println("</html>");

}
}