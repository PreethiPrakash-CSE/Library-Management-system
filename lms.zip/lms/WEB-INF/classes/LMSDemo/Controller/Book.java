package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Book
{
	public String bookid;
	public String bookname;
	public String author;
	public int yop;
	public int quantity;
	
}