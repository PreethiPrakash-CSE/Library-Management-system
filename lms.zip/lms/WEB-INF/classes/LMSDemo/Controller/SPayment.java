package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

import java.util.Date;
import java.text.SimpleDateFormat;

public class SPayment extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	HttpSession session=request.getSession(false);
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	String bookid = request.getParameter("bookid");
	int fine = Integer.parseInt(request.getParameter("fine"));
	String userid=(String)session.getAttribute("userid");
	String status=(String)session.getAttribute("status");
	TeacherExpert te=new TeacherExpert();
	StudentExpert se=new StudentExpert();
	ReserveExpert re=new ReserveExpert();
	int samount=0;
	int reduction;
	String checkwait="";
	String waituser="";

	String date;
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDateTime now = LocalDateTime.now();
	date=dtf.format(now);

	out.println("<html>");
	out.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");

try {
	samount=se.GetAmount(userid);
	waituser=re.GetReserveUser(bookid);
	checkwait=re.CheckWaiting(bookid);
}	

catch (Exception e) {
		e.printStackTrace();
	}
if(samount>fine)
{
	reduction=samount-fine;
	if(checkwait.equals("valid"))
	{
		try{
			se.UpdateStuBalance(reduction,userid);
			out.println("<h3>PAYMENT SUCCESSFUL</h3>");
			out.println("<h3>BOOK RETURNED</h3>");
			se.ReqAvail(userid,"return");
			se.UpdateStuinfo(userid,bookid,"return","date");
			re.InsertReserveUser(waituser,bookid,date);
			re.DeleteReserveUser(waituser,bookid);
			re.UpdateReservePriority(bookid);
			out.println("<form action='sview' method='post'><br>");
			out.println("<button type='submit' >View Balance</button><br></br>");
			out.println("</form>");
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	else
	{

	try {
		se.UpdateStuBalance(reduction,userid);
		out.println("<h3>PAYMENT SUCCESSFUL</h3>");
		out.println("<h3>BOOK RETURNED</h3>");
		se.ReqAvail(userid,"return");
		te.UpdateBookQuant(bookid,"return");
		se.UpdateStuinfo(userid,bookid,"return","date");
		out.println("<form action='sview' method='post'><br>");
		out.println("<button type='submit' >View Balance</button><br></br>");
		out.println("</form>");
		
	}
	catch (Exception e) {
			e.printStackTrace();
		}	
}

}
else
{
	out.println("<h3>IN-SUFFICIENT BALANCE</h3>");
}
	out.println("</div>");
	out.println("</body>");
	out.println("</html>");

}


public int CalculateFine(String issuedate,String required)
{
	String date;
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDateTime now = LocalDateTime.now();
	date=dtf.format(now);

	SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
	int actual_difference=0;
	int daysBetween=0;
	int fine=0;

	try {
		Date dateBefore = myFormat.parse(issuedate);
		Date dateAfter = myFormat.parse(date);
		long difference = dateAfter.getTime() - dateBefore.getTime();
		daysBetween = (int)(difference / (1000*60*60*24));
		System.out.println("Number of Days between dates: "+daysBetween);
	} 
	catch (Exception e) {
		e.printStackTrace();
	}
		if (daysBetween<=7){
		fine=0;

		}
		else{
		actual_difference=daysBetween-7;
		fine=actual_difference*5;
		}

		if(required.equals("days"))
		return daysBetween;
		else 
			return fine;


}

}