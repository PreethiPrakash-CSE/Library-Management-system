package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class StudentSelect extends HttpServlet 
{

public void doGet(HttpServletRequest request, HttpServletResponse res) throws ServletException,IOException
	{

		res.setContentType("application/text");
		PrintWriter pw=res.getWriter();
		StudentExpert se = new StudentExpert();
		AdminExpert ae=new AdminExpert();
		String userid = request.getParameter("userid");
		String status = request.getParameter("status");
			try 
			{


				String exists = ae.checkUsername(userid,status);
				pw.write(exists);
				System.out.println(userid + " " + exists);
				//System.out.println("ready state from ajaxhandler : "+ a);
				
			}catch(Exception e){
				System.out.println("Exception thrown : "+e);
			}
			

		}
		
		
		
	


public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{

HttpSession session =request.getSession(true);
response.setContentType("text/html");

Student s=new Student();
s.userid=request.getParameter("userid");
s.password=request.getParameter("psw");
String status= request.getParameter("status");

session.setAttribute("userid",s.userid);
session.setAttribute("password",s.password);
session.setAttribute("status",status);

PrintWriter out = response.getWriter();
StudentExpert se = new StudentExpert();
Student res=null;
AdminExpert ae = new AdminExpert();
Teacher t=null;

out.println("<html>");
out.println("<head><style>.registerbtn:hover { background-color: #8de0de;}.registerbtn {background-color: #3e13cf;color: white;padding: 10px 5px;margin: 8px 0 0 150px; border: none; cursor: pointer;width: 25%;opacity: 0.9;align-content: center;}#form_login {border: 3px solid black;padding: 25px;left      : 50%;top       : 60%;background-color: #f5faf6; margin-left: 500px;margin-right: 500px;}.acenter{text-align:center;}body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
out.println("<body>");




try{


if(status.equals("student"))  
{
	res=se.LoginResult(s);
		
if(s.userid.equals(res.userid))
	{
		
		if(s.password.equals(res.password)){
				out.println("<div id='form_login'>");
				out.println("<form action='search' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>Search Book</button><br></br>");
				out.println("</form>");
				out.println("<form action='sinrequestbook' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>Request Book</button><br></br>");
				out.println("</form>");
				out.println("<form action='sinreturnbook' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>Return Book</button><br></br>");
				out.println("</form>");
				out.println("<form action='renewexpert' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>Renew Book</button><br></br>");
				out.println("</form>");
				out.println("<form action='confirmreserve' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>View Reserved Books</button><br></br>");
				out.println("</form>");
				out.println("<form action='sview' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>View Profile</button><br></br>");
				out.println("</form>");
				
				out.println("</div>");
				
			
		}
		else
		{
			out.println("<h2 align='center'>Password incorrect.</h2><br><h2 align='center'>Try again</h2>");
		    response.sendRedirect("login.html");
		}

	}
else
	{
		out.println("<h2 align='center'>user id "+s.userid+" does not exists,Try Again</h2>");
		response.sendRedirect("login.html");

	}
		out.println("</body>");
		out.println("</html>");
}
else if(status.equals("teacher"))
{
	t=ae.TeaLoginResult(s);

	if(s.userid.equals(t.userid))
	{
		
		if(s.password.equals(t.password)){
				out.println("<div id='form_login'>");
				out.println("<form action='tinrequestbook' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>Request Book</button><br></br>");
				//out.println("<input type='submit' value='Request Book'>");
				out.println("</form>");
				out.println("<form action='tinreturnbook' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>Return Book</button><br></br>");
				//out.println("<input type='submit' value='Return Book'>");
				out.println("</form>");
				out.println("</div>");
				
			
		}
		else{
			out.println("<h2 align='center'>Password incorrect.</h2><br><h2 align='center'>Try again</h2>");
			response.sendRedirect("login.html");

		}

	}
else
	{
		out.println("<h2 align='center'>user id "+s.userid+" does not exists,Try Again</h2>");
		response.sendRedirect("login.html");

	}
		
}

else if(status.equals("librarian"))
{
	t=ae.LibLoginResult(s);

	if(s.userid.equals(t.userid))
	{
		
		
		if(s.password.equals(t.password)){
				out.println("<div id='form_login'>");
				out.println("<form  action='addbook' method='post'><br>");
				out.println("<button type='submit' class='registerbtn'>Add Book</button><br></br>");
				//out.println("<input type='submit' value='Add book'>");
				out.println("</form>");
				out.println("<form  action='deletebook' method='post' ><br>");
				out.println("<button type='submit' class='registerbtn'>Delete Book</button><br></br>");
				//out.println("<input type='submit' value='Delete Book'>");
				out.println("</form>");
				out.println("<form  action='viewuser' method='post' ><br>");
				out.println("<button type='submit' class='registerbtn'>View User Details</button><br></br>");
				//out.println("<input type='submit' value='View User Details'>");
				out.println("</form>");
				out.println("</form>");
				out.println("<form  action='deleteuser' method='post' ><br>");
				out.println("<button type='submit' class='registerbtn'>Delete User</button><br></br>");
				//out.println("<input type='submit' value='Delete user'>");
				out.println("</form>");
				out.println("<form  action='placeorder' method='post' ><br>");
				out.println("<button type='submit' class='registerbtn'>Place Order</button><br></br>");
				//out.println("<input type='submit' value='Place Order'>");
				out.println("</form>");
				out.println("</div>");
		}
		else{
			out.println("<h2 align='center'>Password incorrect.</h2><br><h2 align='center'>Try again</h2>");
			response.sendRedirect("login.html");

		}

	}
else
	{
		out.println("<h2 align='center'>user id "+s.userid+" does not exists,Try Again</h2>");
		response.sendRedirect("login.html");

	}
		out.println("</body>");
		out.println("</html>");
}

}
catch(Exception E)
{
System.out.println(E);
}






}
}





