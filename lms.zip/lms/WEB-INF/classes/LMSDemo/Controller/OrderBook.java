package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class OrderBook extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	HttpSession session=request.getSession(false);
	response.setContentType("text/html");
	PrintWriter pw = response.getWriter();
	pw.println("<html>");
	pw.println("<head><style>table,th,td {padding: 10px; border: 1px solid black; border-collapse: collapse;}#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	pw.println("<body>");
	pw.println("<div id='form_login'>");
	pw.println("<h3>ORDER PLACED</h3>");
	String bookname = request.getParameter("bookname");
	String bookauthor = request.getParameter("author");
	int yop =Integer.parseInt( request.getParameter("year"));
	int bookquantity =Integer.parseInt( request.getParameter("quantity"));

		

		pw.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
		pw.println("<tr>");
		pw.println("<th>Book name</th>");
		pw.println("<th>Book Author</th>");
		pw.println("<th>Book quantity</th>");
		pw.println("<th>Year of publication</th>");
		pw.println("</tr>");

		
			pw.println("<tr>");
			pw.println("<td>"+bookname+"</td>");
			pw.println("<td>"+bookauthor+"</td>");
			pw.println("<td>"+bookquantity+"</td>");
			pw.println("<td>"+yop+"</td>");
			pw.println("</tr>");
		
		// pw.println("<td>Internet Programming</td>");
		// pw.println("<td>"+score+"</td>");

		pw.println("</table>");
		pw.println("</body>");
		pw.println("</html>");
		}
	}

	
	/*out.println("<table class=center><tr><th>Book Name</th><th>Book Author</th><th>Book Quantity</th><th>Year of publication</th></tr>");
	out.println("<tr><td>"+bookname+"</td><td>"+bookauthor+"</td><td>"+bookquantity+"</td><td>"+yop+"</td></tr>");

	out.println("</table>");
	out.println("</div>");
	out.println("</body>");
	out.println("</html>");

*/

