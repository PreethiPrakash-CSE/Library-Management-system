package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class SReserveBook extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{

	HttpSession session=request.getSession(false);
	response.setContentType("text/html");
	String userid=(String)session.getAttribute("userid");
	PrintWriter out = response.getWriter();
	out.println("<html>");
	out.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	String bookid = request.getParameter("bookid");
	TeacherExpert te=new TeacherExpert();
	ReserveExpert re=new ReserveExpert();
	Book b=new Book();
	int stutablecount=0;
	int restablecount=0;
	int count=0;
	int priority=0;
	String dupreserve="";
	try
	{
		stutablecount=re.CheckValidReserve(bookid,"studentinfo");
		restablecount=re.CheckValidReserve(bookid,"reserve");
		priority=re.GetPriority(bookid)+1;
		count=stutablecount-restablecount;
		dupreserve=re.CheckDuplicateReserve(bookid,userid);
	}

	catch(Exception E)
	{
			System.out.println(E);
	}
	out.println("<div id='form_login'>");
	if(count!=0)
	{
		if(dupreserve.equals("valid")){
		out.println("<h3>BOOK RESERVED</h3>");

		try
	{
		re.InsertReserve(userid,bookid,priority);
		b=te.DisplayReqBook(bookid);
				
		out.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
		out.println("<tr>");
		out.println("<th>BOOK ID</th>");
		out.println("<th>BOOK NAME</th>");
		out.println("<th>AUTHOR</th>");
		out.println("<th>YEAR OF PUBLISH</th>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>"+b.bookid+"</td>");
		out.println("<td>"+b.bookname+"</td>");
		out.println("<td>"+b.author+"</td>");
		out.println("<td>"+b.yop+"</td>");
		out.println("</tr>");
		out.println("</table>");
	}
	catch(Exception E)
	{
			System.out.println(E);
	}
		
	}

	else
	{
		out.println("<h3>BOOK ALREADY RESERVED</h3>");
	}

	}

	else
	{
		out.println("<h3>BOOK RESERVE LIMIT REACHED</h3>");
		out.println("<h3>SORRY TRY AGAIN LATER.</h3>");
	}
	out.println("</div>");
	out.println("</body>");
	out.println("</html>");

}
}