package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;


public class AjaxHandler extends HttpServlet
{
	public AjaxHandler() 
	{
        super();
    }
	public void doGet(HttpServletRequest request, HttpServletResponse res) throws ServletException,IOException
	{

		res.setContentType("application/text");
		PrintWriter pw=res.getWriter();
		StudentExpert se = new StudentExpert();
		AdminExpert ae=new AdminExpert();
		String userid = request.getParameter("userid");
		
		String status = request.getParameter("status");
		try 
			{

				String exists = ae.checkUsername(userid,status);
				pw.write(exists);
				System.out.println(userid + " " + exists);
				//System.out.println("ready state from ajaxhandler : "+ a);
				
			}catch(Exception e){
				System.out.println("Exception thrown : "+e);
			}
			

	}
		
		
		
	

	public void doPost(HttpServletRequest request, HttpServletResponse res) throws ServletException,IOException
	{
		
		Student s=new Student();
		Teacher t=new Teacher();
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		StudentExpert se = new StudentExpert();
		AdminExpert ae = new AdminExpert();
		String status = request.getParameter("status");
		if(status.equals("student"))
		{
		try {

				s.name=request.getParameter("name");
				s.userid=request.getParameter("userid");
				s.password=request.getParameter("password");
				s.yearofjoin=request.getParameter("yoj");
				s.cardno=request.getParameter("cardno");
				s.pin=request.getParameter("pin");

				String exists = ae.checkUsername(s.userid,status);

			
			
			if(exists == "exists"){
				pw.println("<html><head><script>");
				pw.println("alert(\"Invalid Username or Password. Try Again..!\");");
				pw.println("</script></head></html>");
				res.sendRedirect("Register.html");
			}
			else{
				
				se.appendUser(s);
				pw.println("<html><head><script>");
				pw.println("alert(\"Registration Successfull!\");");
				pw.println("</script></head></html>");
				res.sendRedirect("login.html");
			}
			
		}catch(Exception e){
			System.out.println("Exception thrown : "+e);
		}
		}

		else if(status.equals("teacher"))
		{
		try {

				t.name=request.getParameter("name");
				t.userid=request.getParameter("userid");
				t.password=request.getParameter("password");
				t.dept=request.getParameter("dept");

				String exists = ae.checkUsername(t.userid,status);
			
			
			if(exists == "exists"){
				pw.println("<html><head><script>");
				pw.println("alert(\"Invalid Username or Password. Try Again..!\");");
				pw.println("</script></head></html>");
				res.sendRedirect("Register.html");
			}
			else{
				
				ae.appendUser(t);
				pw.println("<html><head><script>");
				pw.println("alert(\"Registration Successfull!\");");
				pw.println("</script></head></html>");
				res.sendRedirect("login.html");
			}
			
		}catch(Exception e){
			System.out.println("Exception thrown : "+e);
		}
		}




	}
}