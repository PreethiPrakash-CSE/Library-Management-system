package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

import java.util.Date;
import java.text.SimpleDateFormat;


public class SRenewBook extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	
	HttpSession session=request.getSession(false);
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	String userid=(String)session.getAttribute("userid");
	String status=(String)session.getAttribute("status");
	String bookid = request.getParameter("bookid");
	TeacherExpert te=new TeacherExpert();
	StudentExpert se=new StudentExpert();
	RenewExpert re=new RenewExpert();
	SPayment sp=new SPayment();

	String valid="";
	int nor=0;
	int fine=0;
	String issuedate="";
	int oldfine=0;

	String date;
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDateTime now = LocalDateTime.now();
	date=dtf.format(now);

	out.println("<html>");
	out.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");
	
	try
		{
		 issuedate=se.GetIssueDate(userid,bookid);
		 valid=te.CheckValidReq(bookid,userid,status);
		 nor=re.GetNor(userid,bookid);
		 oldfine=se.GetFine(userid,bookid);
		 fine=sp.CalculateFine(issuedate,"fine")+oldfine;
		}
	catch(Exception E)
		{
			System.out.println(E);
		}
	if(valid.equals("invalid"))
	{

		
		if(nor>0)
		{
			try{
			re.UpdateNor(userid,bookid);
			re.UpdateIssueDate(userid,bookid,date);
			re.UpdateFine(userid,bookid,fine);
			out.println("<h3>BOOK RENEWED</h3>");
		}
			catch(Exception E)
			{
				System.out.println(E);
			}

		}
		else
		{
			out.println("<h3>RENEWAL LIMIT REACHED</h3>");
		}
	}
	else
	{
		out.println("<h3>CAN RENEW ONLY BOOKS WHICH YOU BOUGHT</h3>");	
	}
		out.println("<form action='renewexpert' method='post'>");
		out.println("<input type='submit' value='Renew Another Book'>");
		out.println("</form>");
}
}