package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class InsertBook extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	HttpSession session=request.getSession(false); 
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	String bookid = request.getParameter("bookid");
	String bookname = request.getParameter("bookname");
	String bookauthor = request.getParameter("bookauthor");
	int yop =Integer.parseInt( request.getParameter("yop"));
	int bookquantity = Integer.parseInt(request.getParameter("bookquantity"));
	LibrarianExpert le=new LibrarianExpert();
	String result="";

	try
	{
	result=le.FindBook(bookid);

	}
	catch(Exception E)
	{
	System.out.println(E);
	}
	out.println("<html>");
	out.println("<head><style>#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");
	if(result.equals("valid"))
	{
		try{
			le.appendBook(bookid,bookname,bookauthor,yop,bookquantity);
		}
		catch(Exception E)
		{
		System.out.println(E);
		}
		out.println("<h3>BOOK INSERTED SUCCESSFULLY</h3>");
	}
	else
	{
		try{
			le.UpdateQuantity(bookid,bookquantity);
		}
		catch(Exception E)
		{
		System.out.println(E);
		}
		out.println("<h3>BOOK QUANTITY UPDATED.</h3>");
	
	}
	

	out.println("</div>");
	out.println("</body>");
	out.println("</html>");


}

}