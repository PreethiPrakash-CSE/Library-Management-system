package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class StudentInfo
{
	public String userid;
	public String bookid;
	public String issuedate;
	public int nor;
	public int fine;
	public String status;
	
}