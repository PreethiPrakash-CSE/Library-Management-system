package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class RequestBook extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	HttpSession session=request.getSession(false);
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	String userid=(String)session.getAttribute("userid");
	String status=(String)session.getAttribute("status");
	String bookid = request.getParameter("bookid");
	String result="";
	TeacherExpert te=new TeacherExpert();
	try
	{
		result=te.CheckBookAvail(bookid,"request",userid,status);
	}
	catch(Exception E)
	{
		System.out.println(E);
	}
	out.println("<html>");
	out.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");
	if(result.equals("Available")){
		out.println("<h3>BOOK REQUESTED</h3>");
		try
		{
			String valid=te.CheckValidReq(bookid,userid,status);
			Book b=new Book();
			if(valid.equals("valid"))
			{
				te.UpdateBookQuant(bookid,"request");
				te.UpdateTeainfo(userid,bookid,"request");

				b=te.DisplayReqBook(bookid);
			
				out.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
				out.println("<tr>");
				out.println("<th>BOOK ID</th>");
				out.println("<th>BOOK NAME</th>");
				out.println("<th>AUTHOR</th>");
				out.println("<th>YEAR OF PUBLISH</th>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<td>"+b.bookid+"</td>");
				out.println("<td>"+b.bookname+"</td>");
				out.println("<td>"+b.author+"</td>");
				out.println("<td>"+b.yop+"</td>");
				out.println("</tr>");
				out.println("</table>");
			}
			else
			{
				out.println("<h3>ONLY ONE REQUEST PER USER</h3>");
			}

		}
		catch(Exception E)
		{
			System.out.println(E);
		}
	}
	else
	{
		out.println("<h3>BOOK NOT AVAILABLE</h3>");	
		out.println("<form action='tinrequestbook' method='post'>");
		out.println("<input type='submit' value='Request Another Book'>");
		out.println("</form>");
	}

	out.println("</div>");
	out.println("</body>");
	out.println("</html>");
	


}

}