package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;


public class AjaxPass extends HttpServlet
{
	public AjaxPass() 
	{
        super();
    }
	public void doGet(HttpServletRequest request, HttpServletResponse res) throws ServletException,IOException
	{

		res.setContentType("application/text");
		PrintWriter pw=res.getWriter();
		AdminExpert ae=new AdminExpert();
		String userid=request.getParameter("userid");
		String password = request.getParameter("password");
		String status = request.getParameter("status");
			try 
			{
				String exists = ae.checkPassword(userid,password,status);
								
				pw.write(exists);
				System.out.println(password + " " + exists);
				//System.out.println("ready state from ajaxhandler : "+ a);
				
			}catch(Exception e){
				System.out.println("Exception thrown : "+e);
			}
			

		}



		public void doPost(HttpServletRequest request, HttpServletResponse res) throws ServletException,IOException
	{
		
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		AdminExpert ae = new AdminExpert();
		String status = request.getParameter("status");
		
		try {

				String userid=request.getParameter("userid");
				String password=request.getParameter("newpwd");
				

				ae.UpdatePass(userid,password,status);
				res.sendRedirect("login.html");

			
			
		}catch(Exception e){
			System.out.println("Exception thrown : "+e);
		}
	}
		
		
	}
			