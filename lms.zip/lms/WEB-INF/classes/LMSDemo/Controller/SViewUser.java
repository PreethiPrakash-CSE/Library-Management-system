package LMSDemo.Controller;
import LMSDemo.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



public class SViewUser extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException //,Exception
{
	HttpSession session=request.getSession(false);
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	out.println("<html>");
	out.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}#form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
	out.println("<body>");
	out.println("<div id='form_login'>");
	String userid=(String)session.getAttribute("userid");
	StudentExpert se=new StudentExpert();
	out.println("<h3>USER DETAILS</h3>");
	try
		{
			
				Student s=new Student();
			
				s=se.Details(userid);
			
				out.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
				out.println("<tr>");
				out.println("<th>USER ID</th>");
				out.println("<td>"+s.userid+"</td>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<th>NAME</th>");
				out.println("<td>"+s.name+"</td>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<th>PASSWORD</th>");
				out.println("<td>"+s.password+"</td>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<th>AMOUNT</th>");
				out.println("<td>"+s.amount+"</td>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<th>REQ AVAIL</th>");
				out.println("<td>"+s.reqavail+"</td>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<th>YEAR OF JOIN</th>");
				out.println("<td>"+s.yearofjoin+"</td>");
				out.println("</tr>");
				out.println("</table>");
			
			

		}
		catch(Exception E)
		{
			System.out.println(E);
		}
	out.println("</div>");
	out.println("</body>");
	out.println("</html>");

}
}