package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class RenewExpert extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

		HttpSession session=request.getSession(false);
		response.setContentType("text/html");
		String userid=(String)session.getAttribute("userid");
		String status=(String)session.getAttribute("status");

		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql="";
			
			
				sql="select * from studentinfo where status='request' and suserid='" + userid + "'";
			ResultSet rs = st.executeQuery(sql);

		
		StudentInfo si=new StudentInfo();
		si.userid="";
		si.bookid="";
		si.issuedate="";
		si.nor=0;
		si.fine=0;
		
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}  #form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
		pw.println("<body>");
		pw.println("<div id='form_login'>");
		pw.println("<h3>BOOK HISTORY <b></b></h3>");

		pw.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
		pw.println("<tr>");
		pw.println("<th>USER ID</th>");
		pw.println("<th>BOOK ID</th>");
		pw.println("<th>LAST RENEWED DATE</th>");
		pw.println("<th>RENEWALS AVAILABLE</th>");
		pw.println("</tr>");
		while (rs.next()){
			si.userid=rs.getString("suserid");
			si.bookid=rs.getString("bookid");
			si.issuedate=rs.getString("issuedate");
			si.nor=rs.getInt("nor");
			si.fine=rs.getInt("fine");
			
		
			pw.println("<tr>");
			pw.println("<td>"+si.userid+"</td>");
			pw.println("<td>"+si.bookid+"</td>");
			pw.println("<td>"+si.issuedate+"</td>");
			pw.println("<td>"+si.nor+"</td>");
			pw.println("</tr>");
		
			
		}

		pw.println("</table>");
			
		pw.println("<form  action='srenewbook' method='post'><br>");
		pw.println("Enter Book id:");
		pw.println("<input type='text' name='bookid'><br><br>");
		pw.println("<input type='submit' value='Renew Book'>");			
		pw.println("</form>");
		
		pw.println("</body>");
		pw.println("</html>");

		}catch(Exception e){
			System.out.println(e);
		}
	}

	public int GetNor(String userid,String bookid) throws Exception
	{
		int nor=0;
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();
		String query = "select * from studentinfo where bookid = \'" + bookid + "\' and suserid = \'" + userid + "\'";
		ResultSet rs = st.executeQuery(query);
		if (!rs.next()){

		System.out.println("no data");
		return nor;
		}
		else{
		nor=rs.getInt("nor");
		return nor;
		}
	}

	public void UpdateNor(String userid,String bookid) throws Exception
	{
		try
		{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

			Statement st = con.createStatement();
			String query = "update studentinfo set nor=nor-1 where bookid = \'" + bookid + "\' and suserid = \'" + userid + "\'";
			st.executeUpdate(query);
		}

		catch(Exception e){
			System.out.println(e);
		}
		
	}

	public void UpdateIssueDate(String userid,String bookid,String issuedate) throws Exception
	{
		try
		{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

			Statement st = con.createStatement();
			String query = "update studentinfo set issuedate=\'" + issuedate + "\' where bookid = \'" + bookid + "\' and suserid = \'" + userid + "\'";
			st.executeUpdate(query);
		}

		catch(Exception e){
			System.out.println(e);
		}
		
	}

	public void UpdateFine(String userid,String bookid,int fine) throws Exception
	{
		try
		{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

			Statement st = con.createStatement();
			String query = "update studentinfo set fine=\'" + fine + "\' where bookid = \'" + bookid + "\' and suserid = \'" + userid + "\'";
			st.executeUpdate(query);
		}

		catch(Exception e){
			System.out.println(e);
		}
		
	}
}
