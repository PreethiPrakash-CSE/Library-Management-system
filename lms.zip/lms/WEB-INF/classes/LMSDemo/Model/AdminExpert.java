package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;


public class AdminExpert
{

public Teacher TeaLoginResult(Student s) throws Exception
{

		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";

//2. Load JDBC Driver and register the driver
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

		System.out.println("Hey I am after forname method");

//3. Open a Connection
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
//Connection conn = DriverManager.getConnection(url,user,password);
		System.out.println("con--->"+con);

Statement st = con.createStatement();
//String sql="INSERT INTO coffeedetails(color,brand) VALUE('lightbrown','narasurs')";

System.out.println("Hey I am after create statement");

String query = "select * from teacher where userid = \'" + s.userid + "\'";
ResultSet rs = st.executeQuery(query);

Teacher newuser=new Teacher();
newuser.userid="";
newuser.password="";
System.out.println("Hey Im before if");

if (!rs.next()){
	
    System.out.println("no data");
    return newuser;
}
else{
System.out.println("user id:"+rs.getString("userid"));
System.out.println("password:"+rs.getString("password"));
newuser.userid=rs.getString("userid");
newuser.password=rs.getString("password");

return newuser;
}


}

public Teacher LibLoginResult(Student s) throws Exception
{

		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";

//2. Load JDBC Driver and register the driver
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

		System.out.println("Hey I am after forname method");

//3. Open a Connection
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
//Connection conn = DriverManager.getConnection(url,user,password);
		System.out.println("con--->"+con);

Statement st = con.createStatement();
//String sql="INSERT INTO coffeedetails(color,brand) VALUE('lightbrown','narasurs')";

System.out.println("Hey I am after create statement");

String query = "select * from librarian where userid = \'" + s.userid + "\'";
ResultSet rs = st.executeQuery(query);

Teacher newuser=new Teacher();
newuser.userid="";
newuser.password="";
System.out.println("Hey Im before if");

if (!rs.next()){
	
    System.out.println("no data");
    return newuser;
}
else{
System.out.println("user id:"+rs.getString("userid"));
System.out.println("password:"+rs.getString("password"));
newuser.userid=rs.getString("userid");
newuser.password=rs.getString("password");

return newuser;
}


}

public String checkUsername(String userid,String status) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/mainexam_db";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			if(status.equals("student"))
			{
				sql = "select * from student where userid = '" + userid + "'";
			}


			else if(status.equals("teacher"))
			{
				sql = "select * from teacher where userid = '" + userid + "'";
			}


			else if(status.equals("librarian"))
			{
				sql = "select * from librarian where userid = '" + userid + "'";
			}
			
			ResultSet rs = st.executeQuery(sql);
			
			if(rs.next()){
				return "exists";
			}
			
			else{
				return "does not exist";
			}
			
		}catch(Exception e){
			System.out.println(e);
			return "0";
		}
	}


public String checkPassword(String userid,String pass,String status) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			String sql="";

			if(status.equals("student"))
			{
				sql = "select * from student where userid = '" + userid + "' and password='" + pass + "'";
			}


			else if(status.equals("teacher"))
			{
				sql = "select * from teacher where userid = '" + userid + "' and password='" + pass + "'";
			}


			else if(status.equals("librarian"))
			{
				sql = "select * from librarian where userid = '" + userid + "' and password='" + pass + "'";
			}

			ResultSet rs = st.executeQuery(sql);
		
			
			if(rs.next()){
				return "exists";
			}
			
			else{
				return "does not exist";
			}
			
		}catch(Exception e){
			System.out.println(e);
			return "0";
		}
	}


public void appendUser(Teacher t) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql = "insert into teacher values(\"" + t.userid + "\",\""+t.name+"\",\""+t.dept+"\",\""+t.password+"\")";


			
			st.executeUpdate(sql);
		}catch(Exception e){
			System.out.println(e);
		}
	}

public void UpdatePass(String userid,String pass,String status) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			if(status.equals("student"))
			{
				sql = "update student set Password='" + pass + "'where userid='" + userid + "'";
				
			}


			else if(status.equals("teacher"))
			{
				sql = "update teacher set Password='" + pass + "'where userid='" + userid + "'";
			}
 

			
			st.executeUpdate(sql);
		}catch(Exception e){
			System.out.println(e);
		}
	}

}


