package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;
import java.sql.ResultSet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class FindAuthor extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String author=request.getParameter("author");
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			Statement st=con.prepareStatement("select typeid from users where username=? and password=?",ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			//Statement st = con.createStatement();
			
			
			String sql="";
			sql = "select * from book where author = \'" + author + "\'";
			
			
				
			ResultSet rs = st.executeQuery(sql);
			PrintWriter pw = response.getWriter();
			if(rs.next()==false)
			{
				pw.println("<html>");
				pw.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}  #form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
				pw.println("<body>");
				pw.println("<div id='form_login'>");
				pw.println("<h3>Book Not found with the author name <b></b></h3>");
			}
			else{

				rs.beforeFirst();
		
		String bookid="";
		String bookname="";
		int yop=0;
		
		pw.println("<html>");
		pw.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}  #form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
		pw.println("<body>");
		pw.println("<div id='form_login'>");
		pw.println("<h3>Book Details <b></b></h3>");

		pw.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
		pw.println("<tr>");
		pw.println("<th>BOOK ID</th>");
		pw.println("<th>BOOK NAME</th>");
		pw.println("<th>YEAR OF PUBLISH</th>");
		pw.println("</tr>");
		while (rs.next()){
			bookid=rs.getString("bookid");
			bookname=rs.getString("bookname");
			yop=rs.getInt("year");
			
		

		
		

		
			pw.println("<tr>");
			pw.println("<td>"+bookid+"</td>");
			pw.println("<td>"+bookname+"</td>");
			pw.println("<td>"+yop+"</td>");
			pw.println("</tr>");
		
			
		}
	}

		pw.println("</table>");
			

		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");

		}catch(Exception e){
			System.out.println(e);
		}
	}
}
