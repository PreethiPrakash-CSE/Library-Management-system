package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class LibTeaView extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		HttpSession session=request.getSession(false);
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql="";


				sql = "select t.userid,t.name,t.department,tin.bookid,b.bookname,b.author from teacher as t inner join teacherinfo as tin on tin.tuserid=t.userid inner join book as b on tin.bookid=b.bookid";

			ResultSet rs = st.executeQuery(sql);

		String userid="";
		String name="";
		String dept="";
		String bookid="";
		String bookname="";
		String author="";
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}  #form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
		pw.println("<body>");
		pw.println("<div id='form_login'>");
		pw.println("<h3>Faculty Member Details <b></b></h3>");

		pw.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
		pw.println("<tr>");
		pw.println("<th>USER ID</th>");
		pw.println("<th>USER NAME</th>");
		pw.println("<th>DEPARTMENT</th>");
		pw.println("<th>BOOK ID</th>");
		pw.println("<th>BOOK NAME</th>");
		pw.println("<th>AUTHOR</th>");
		pw.println("</tr>");
		while (rs.next()){
			userid=rs.getString("userid");
			name=rs.getString("name");
			dept=rs.getString("department");
			bookid=rs.getString("bookid");
			bookname=rs.getString("bookname");
			author=rs.getString("author");
			
			pw.println("<tr>");
			pw.println("<td>"+userid+"</td>");
			pw.println("<td>"+name+"</td>");
			pw.println("<td>"+dept+"</td>");
			pw.println("<td>"+bookid+"</td>");
			pw.println("<td>"+bookname+"</td>");
			pw.println("<td>"+author+"</td>");
			pw.println("</tr>");
		
			
		}
		pw.println("</table>");
		

		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");

		}catch(Exception e){
			System.out.println(e);
		}
	}
}
