package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;

public class StudentExpert
{

public Student LoginResult(Student s) throws Exception
{

		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";

//2. Load JDBC Driver and register the driver
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

		System.out.println("Hey I am after forname method");

//3. Open a Connection
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
//Connection conn = DriverManager.getConnection(url,user,password);
		System.out.println("con--->"+con);

Statement st = con.createStatement();
//String sql="INSERT INTO coffeedetails(color,brand) VALUE('lightbrown','narasurs')";

System.out.println("Hey I am after create statement");

String query = "select * from student where userid = \'" + s.userid + "\'";
ResultSet rs = st.executeQuery(query);

Student newstu=new Student();
newstu.userid="";
newstu.password="";
System.out.println("Hey Im before if");

if (!rs.next()){
	
    System.out.println("no data");
    return newstu;
}
else{
System.out.println("user id:"+rs.getString("userid"));
System.out.println("password:"+rs.getString("password"));
newstu.userid=rs.getString("userid");
newstu.password=rs.getString("Password");
return newstu;
}


}

public void UpdateStuinfo(String userid,String bookid,String action,String issuedate) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			
			
			if(action.equals("request")){
				sql = "insert into studentinfo values('"+ userid +"','"+ bookid +"',10,'"+ issuedate +"',0,'"+ action +"')";
			}
			
			else if(action.equals("return")){
				sql= "delete from studentinfo  where bookid='"+ bookid +"' and suserid='"+ userid +"'";
			}
			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}

	public void ReqAvail(String userid,String action) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			
			
			if(action.equals("request")){
				sql = "update student set reqavail=reqavail-1 where userid='"+ userid +"'";
			}
			
			else if(action.equals("return")){
				sql= "update student set reqavail=reqavail+1 where userid='"+ userid +"'";
			}
			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}

	public int GetReqAvail(String userid) throws Exception
	{
		int avail=0;
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();
		String query = "select * from student where userid = \'" + userid + "\'";
		ResultSet rs = st.executeQuery(query);
		if (!rs.next()){

		System.out.println("no data");
		return avail;
		}
		else{
			avail=rs.getInt("reqavail");
			return avail;
		}
	}


public Student Details(String userid) throws Exception
{

		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";

//2. Load JDBC Driver and register the driver
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

		System.out.println("Hey I am after forname method");

//3. Open a Connection
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
//Connection conn = DriverManager.getConnection(url,user,password);
		System.out.println("con--->"+con);

Statement st = con.createStatement();
//String sql="INSERT INTO coffeedetails(color,brand) VALUE('lightbrown','narasurs')";

System.out.println("Hey I am after create statement");

String query = "select * from student where userid = \'" + userid + "\'";
ResultSet rs = st.executeQuery(query);

Student newstu=new Student();
newstu.userid=userid;
newstu.password="";
newstu.amount=0;
newstu.reqavail=0;
newstu.yearofjoin="";
System.out.println("Hey Im before if");

if (!rs.next()){
	
    System.out.println("no data");
    return newstu;
}
else{
//newstu.userid=rs.getString("userid");
newstu.name=rs.getString("Name");
newstu.password=rs.getString("Password");
newstu.amount=rs.getInt("Amount");
newstu.reqavail=rs.getInt("Reqavail");
newstu.yearofjoin=rs.getString("Yearofjoin");
return newstu;
}
}




public String checkUsername(Student s) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			

			String sql = "select * from student where userid = '" + s.userid + "'";

			ResultSet rs = st.executeQuery(sql);
			
			if(rs.next()){
				System.out.println("if condition");
				return "exists";
			}
			
			else{
				return "does not exist";
			}
			
		}catch(Exception e){
			System.out.println(e);
			return "0";
		}
	}

	public String checkPassword(Student s) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			

			String sql = "select * from student where userid = '" + s.userid + "'";

			ResultSet rs = st.executeQuery(sql);
			Student newstu=new Student();
			newstu.userid="";
			newstu.password="";

			
			if(rs.next()){

				newstu.userid=rs.getString("userid");
				newstu.password=rs.getString("Password");

				if(s.password.equals(newstu.password))
				{
					return "exists";
				}

				return "does not exist";
				
			}
			
			else{
				return "does not exist";
			}
			
		}catch(Exception e){
			System.out.println(e);
			return "0";
		}
	}

	public void appendUser(Student s) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			String sql = "insert into student values(\"" + s.userid + "\",\""+s.name+"\",\""+s.password+"\",\""+s.cardno+"\",\""+s.pin+"\",5000,5,\""+s.yearofjoin+"\")";

			
			st.executeUpdate(sql);
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	public String GetIssueDate(String userid,String bookid) throws Exception
	{
		String issuedate="";
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();
		String query = "select * from studentinfo where bookid = \'" + bookid + "\' and suserid = \'" + userid + "\'";
		ResultSet rs = st.executeQuery(query);
		if (!rs.next()){

		System.out.println("no data");
		return "nodate";
		}
		else{
		issuedate=rs.getString("issuedate");
		return issuedate;
		}
	}

	public int GetFine(String userid,String bookid) throws Exception
	{
		int fine=0;
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();
		String query = "select * from studentinfo where bookid = \'" + bookid + "\' and suserid = \'" + userid + "\'";
		ResultSet rs = st.executeQuery(query);
		if (!rs.next()){

		System.out.println("no data");
		return fine;
		}
		else{
		fine=rs.getInt("fine");
		return fine;
		}
	}

	public int GetAmount(String userid) throws Exception
{

	String url = "jdbc:mysql://localhost:3306/library";
	String user = "root";
	String password = "preethi";
	Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
	int amt;
	Statement st = con.createStatement();
	//String query = "update student set amount=amount-\'"+amt +"where suserid = \'" + userid + "\'";
	String query = "select * from student where userid = \'" + userid + "\'";
	ResultSet rs = st.executeQuery(query);
	if (!rs.next()){

	System.out.println("no data");
	return 0;
	}
	else{
	amt=rs.getInt("amount");
	return amt;
	}
}




public void UpdateStuBalance(int reduction,String userid) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";

			sql= "update student set Amount='" + reduction + "' where userid = '" + userid + "'";
			
			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}

public Book BookDetails(String bookid) throws Exception
{

		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

		System.out.println("Hey I am after forname method");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		System.out.println("con--->"+con);

		Statement st = con.createStatement();

		String query = "select * from book where bookid = \'" + bookid + "\'";
		ResultSet rs = st.executeQuery(query);

		Book newb=new Book();
		newb.bookid="";
		newb.bookname="";
		newb.author="";
		newb.yop=0;

		if (!rs.next()){
			
		    System.out.println("no data");
		    return newb;
		}
		else{
		newb.bookid=rs.getString("bookid");
		newb.bookname=rs.getString("bookname");
		newb.author=rs.getString("author");
		newb.yop=rs.getInt("year");

		return newb;
		}
	}
	

}
