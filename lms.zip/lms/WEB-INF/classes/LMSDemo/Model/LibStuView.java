package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class LibStuView extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql="";
			
			
				sql="select s.userid,s.name,s.yearofjoin,st.bookid,st.nor,st.issuedate,b.bookname,b.author from student as s inner join studentinfo as st on s.userid=st.suserid inner join book as b on st.bookid=b.bookid";
			ResultSet rs = st.executeQuery(sql);

		String userid="";
		String name="";
		String yoj="";
		String bookid="";
		String issuedate="";
		String bookname="";
		String author="";
		int nor=0;
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}  #form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
		pw.println("<body>");
		pw.println("<div id='form_login'>");
		pw.println("<h3>Student Details <b></b></h3>");

		pw.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
		pw.println("<tr>");
		pw.println("<th>USER ID</th>");
		pw.println("<th>USER NAME</th>");
		pw.println("<th>YEAR OF JOIN</th>");
		pw.println("<th>BOOK ID</th>");
		pw.println("<th>BOOK NAME</th>");
		pw.println("<th>AUTHOR</th>");
		pw.println("<th>ISSUE DATE</th>");
		pw.println("<th>NUMBER OF RENEWALS</th>");
		pw.println("</tr>");
		while (rs.next()){
			userid=rs.getString("userid");
			name=rs.getString("name");
			yoj=rs.getString("yearofjoin");
			bookid=rs.getString("bookid");
			bookname=rs.getString("bookname");
			author=rs.getString("author");
			issuedate=rs.getString("issuedate");
			nor=rs.getInt("nor");
		

		
		

		
			pw.println("<tr>");
			pw.println("<td>"+userid+"</td>");
			pw.println("<td>"+name+"</td>");
			pw.println("<td>"+yoj+"</td>");
			pw.println("<td>"+bookid+"</td>");
			pw.println("<td>"+bookname+"</td>");
			pw.println("<td>"+author+"</td>");
			pw.println("<td>"+issuedate+"</td>");
			pw.println("<td>"+nor+"</td>");
			pw.println("</tr>");
		
			
		}

		pw.println("</table>");
			

		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");

		}catch(Exception e){
			System.out.println(e);
		}
	}
}
