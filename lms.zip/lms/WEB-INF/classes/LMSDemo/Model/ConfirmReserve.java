package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class ConfirmReserve extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

		HttpSession session=request.getSession(false);
	response.setContentType("text/html");

		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			String userid=(String)session.getAttribute("userid");
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql="";
			
			sql="select * from studentinfo where suserid= '" + userid + "'and status='reserve'";
			
			ResultSet rs = st.executeQuery(sql);

		String suserid="";	
		String bookid="";
		String issuedate="";
		String stat="";
		
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}  #form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
		pw.println("<body>");
		pw.println("<div id='form_login'>");
		

		
		
			pw.println("<h3>Reserved Book Details <b></b></h3>");

			pw.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
			pw.println("<tr>");
			pw.println("<th>USER ID</th>");
			pw.println("<th>BOOK ID</th>");
			pw.println("<th>ISSUE DATE</th>");
			pw.println("<th>STATUS</th>");
			pw.println("</tr>");

		while (rs.next()){
			suserid=rs.getString("suserid");
			bookid=rs.getString("bookid");
			issuedate=rs.getString("issuedate");
			stat=rs.getString("status");
	
			pw.println("<tr>");
			pw.println("<td>"+suserid+"</td>");
			pw.println("<td>"+bookid+"</td>");
			pw.println("<td>"+issuedate+"</td>");
			pw.println("<td>"+stat+"</td>");
			pw.println("</tr>");
			pw.println("</table>");
			
			}

			pw.println("<form action='acceptreserve' method='post'><br>");
			pw.println("<button type='submit' >Collect Books</button><br></br>");
			pw.println("</form>");
		
			
		

		
		pw.println("</body>");
		pw.println("</html>");

		}catch(Exception e){
			System.out.println(e);
		}
	}
}
