package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;
import java.io.*;

public class TeacherExpert {
	public String CheckBookAvail(String bookid,String action,String userid,String status) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			

			if(action.equals("request")){
				sql= "select * from book where quantity > 0 and bookid = '" + bookid + "'";
			}
			
			else if((action.equals("return"))&&(status.equals("teacher"))){
				sql= "select * from teacherinfo where bookid = '" + bookid + "'and tuserid='"+ userid +"'";
			}
			else if((action.equals("return"))&&(status.equals("student"))){
				sql= "select * from studentinfo where bookid = '" + bookid + "'and suserid='"+ userid +"'";
			}

				
			
			
			ResultSet rs = st.executeQuery(sql);
			
			if(rs.next()){
				return "Available";
			}
			
			else{
				return "Not Available";
			}
			
		}catch(Exception e){
			System.out.println(e);
			return "0";
		}
	}

	public void UpdateBookQuant(String bookid,String action) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			
			
			if(action.equals("request")){
				sql= "update book set quantity=quantity-1 where bookid = '" + bookid + "'";
			}
			
			else if(action.equals("return")){
				sql= "update book set quantity=quantity+1 where bookid = '" + bookid + "'";
			}
			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}

	public void UpdateTeainfo(String userid,String bookid,String action) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			
			
			if(action.equals("request")){
				sql = "insert into teacherinfo values('"+ userid +"','"+ bookid +"')";
			}
			
			else if(action.equals("return")){
				sql= "delete from teacherinfo  where bookid='"+ bookid +"' and tuserid='"+ userid +"'";
			}
			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}

	public Book DisplayReqBook(String bookid) throws Exception
	{
		
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			
				sql = "select * from book where bookid = '" + bookid + "'";
				Book b= new Book();
			
			b.bookid="";
			b.bookname="";
			b.author="";
			b.yop=0;
			ResultSet rs = st.executeQuery(sql);
			
			
			if(rs.next()){
				b.bookid=rs.getString("bookid");
				b.bookname=rs.getString("bookname");
				b.author=rs.getString("author");
				b.yop=rs.getInt("year");
				return b;
			}
			
			else{
				return b;
			}
			

	}
	public String CheckValidReq(String bookid,String userid,String status) throws Exception
		{
		try{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();
		String sql="";
		if(status.equals("student")){
		sql="select * from studentinfo info where bookid = '" + bookid + "' and suserid ='"+ userid+"'" ;
		}
		if(status.equals("teacher")){
		sql="select * from teacherinfo info where bookid = '" + bookid + "' and tuserid ='"+ userid+"'" ;
		}



		ResultSet rs = st.executeQuery(sql);

		if(!rs.next()){
		return "valid";
		}

		else{
		return "invalid";
		}

		}catch(Exception e){
		System.out.println(e);
		return "0";
		}
		}
}
