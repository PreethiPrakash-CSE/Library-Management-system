package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;

public class ReserveExpert
{

public int CheckValidReserve(String bookid,String table) throws Exception
	{
		try{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();
		String sql="";
		if(table.equals("studentinfo"))
		{
			sql="select count(*) from studentinfo where bookid=\'" + bookid + "\' and status='request'" ;
		}
		else if(table.equals("reserve"))
		{
			sql="select count(*) from reserve where bookid=\'" + bookid + "\'" ;
		}
		
		int count=0;


		ResultSet rs = st.executeQuery(sql);

		if (!rs.next()){
	
	    System.out.println("no data");
	    return count;
		}
		else{
		
		count=rs.getInt("count(*)");
		
		return count;
		}

		}catch(Exception e){
		System.out.println(e);
		return 0;
		}
	}

	public int GetPriority(String bookid) throws Exception
	{
		try{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		int priority=0;

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();
		String sql="";

		sql="select * from reserve where bookid=\'" + bookid + "\' and priority=(select max(priority) from reserve)";

		ResultSet rs = st.executeQuery(sql);

		if (!rs.next()){
	
	    System.out.println("no data");
	    return priority;
		}
		else{
		
		priority=rs.getInt("priority");
		
		return priority;
		}

		}catch(Exception e){
		System.out.println(e);
		return 0;
		}

	}

	public void InsertReserve(String userid,String bookid,int priority) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			String sql = "insert into reserve values(\"" + userid + "\",\""+bookid+"\",\""+priority+"\")";

			
			st.executeUpdate(sql);
		}catch(Exception e){
			System.out.println(e);
		}
	}

public String CheckDuplicateReserve(String bookid,String userid) throws Exception
{
		try{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";



		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);



		Statement st = con.createStatement();
		String sql="";
		sql="select * from reserve where bookid = '" + bookid + "' and userid ='"+ userid+"'" ;
		ResultSet rs = st.executeQuery(sql);



		if(!rs.next()){
		return "valid";
		}



		else{
		return "invalid";
		}



		}catch(Exception e){
		System.out.println(e);
		return "0";
		}
}

public String GetReserveUser(String bookid) throws Exception
{
		try
		{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		String uid="";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);



		Statement st = con.createStatement();
		String sql="";
		sql="select * from reserve where bookid = '" + bookid + "' and priority=(select min(priority) from reserve)" ;
		ResultSet rs = st.executeQuery(sql);
		if(rs.next()){
		uid=rs.getString("userid");
		return uid;
		}



		else{
		return uid;
		}



		}catch(Exception e){
		System.out.println(e);
		return "0";
		}
}


public void InsertReserveUser(String userid,String bookid,String date) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			sql = "insert into studentinfo values(\"" + userid + "\",\""+bookid+"\",10,\""+date+"\",0,'reserve')";

			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}


public void DeleteReserveUser(String userid,String bookid) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			sql = "delete from reserve where bookid='" + bookid + "' and userid='" + userid + "'";

			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}


public void UpdateReservePriority(String bookid) throws Exception
	{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			String sql="";
			
			sql = "update reserve set priority=priority-1 where bookid='" + bookid + "'";

			st.executeUpdate(sql);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
	}
public String CheckWaiting(String bookid) throws Exception
{
		try{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";



		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);



		Statement st = con.createStatement();
		String sql="";
		sql="select * from reserve where bookid = '" + bookid + "'" ;
		ResultSet rs = st.executeQuery(sql);



		if(!rs.next()){
		return "invalid";
		}



		else{
		return "valid";
		}



		}catch(Exception e){
		System.out.println(e);
		return "0";
		}
}

public void ChangeStatus(String userid,String date)
{
		try{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);



		Statement st = con.createStatement();
		String sql="";
		sql="update studentinfo set status='request' , issuedate ='"+ date +"' where suserid='"+userid+"' and status='reserve'";
		st.executeUpdate(sql);
		}
		catch(Exception e){
		System.out.println(e);

		}
}

}