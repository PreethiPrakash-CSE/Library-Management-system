package LMSDemo.Model;
import LMSDemo.Model.*;
import LMSDemo.Controller.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;


public class LibrarianExpert extends HttpServlet {

	public void appendBook(String bid,String bname,String bauthor,int yop,int bquant) throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql = "insert into Book values(\"" + bid + "\",\""+bname+"\",\""+bauthor+"\",\""+yop+"\",\""+bquant+"\")";


			
			st.executeUpdate(sql);
		}catch(Exception e){
			System.out.println(e);
		}

	}

	public void removeBook(String bid) throws Exception{
		try{
		String url = "jdbc:mysql://localhost:3306/library";
		String user = "root";
		String password = "preethi";

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);

		Statement st = con.createStatement();


		String sql = "delete from Book where bookid= \'" + bid + "\'";





		st.executeUpdate(sql);
		}catch(Exception e){
		System.out.println(e);
		}
	}

	public String FindBook(String bookid) throws Exception
{

	String url = "jdbc:mysql://localhost:3306/library";
	String user = "root";
	String password = "preethi";
	Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
	int amt;
	Statement st = con.createStatement();
	
	String query = "select * from book where bookid = \'" + bookid + "\'";
	ResultSet rs = st.executeQuery(query);
	if (!rs.next()){

	System.out.println("no data");
	return "valid";
	}
	else{
	amt=rs.getInt("amount");
	return "invalid";
	}
}

public void UpdateQuantity(String bookid,int quantity) throws Exception
{

	String url = "jdbc:mysql://localhost:3306/library";
	String user = "root";
	String password = "preethi";
	Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
	int amt;
	Statement st = con.createStatement();
	
	String query = "update book set quantity = \'" + quantity + "\' where bookid=\'"+ bookid +"\'";
	st.executeQuery(query);
	
}



	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql = "select * from student  where 2021-yearofjoin>4";
			ResultSet rs = st.executeQuery(sql);

		Student newstu=new Student();
		newstu.userid="";
		newstu.name="";
		newstu.yearofjoin="";
		System.out.println("Hey Im before if");
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head><style>table, th, td, tr {padding: 10px; border: 1px solid black; border-collapse: collapse;}  #form_login {border: 3px solid black;padding: 100px;left      : 50%;top       : 60%;position  : absolute;transform : translate(-50%, -50%); background-color: #f5faf6; }body{	background-image: url('bg.jpeg'); background-repeat: no-repeat;	height: 100%; background-size: cover; }</style></head>");
		pw.println("<body>");
		pw.println("<div id='form_login'>");
		pw.println("<table style=\"border: 1px solid black; border-collapse: collapse;\">");
		pw.println("<h3>PASSED OUT STUDENTS</h3>");
		pw.println("<tr>");
		pw.println("<th>USER ID</th>");
		pw.println("<th>USER NAME</th>");
		pw.println("<th>YEAR OF JOIN</th>");
		pw.println("</tr>");
		while (rs.next()){
			newstu.userid=rs.getString("userid");
			newstu.name=rs.getString("name");
			newstu.yearofjoin=rs.getString("yearofjoin");
			pw.println("<tr>");
			pw.println("<td>"+newstu.userid+"</td>");
			pw.println("<td>"+newstu.name+"</td>");
			pw.println("<td>"+newstu.yearofjoin+"</td>");
			pw.println("</tr>");
		
			
		}
		pw.println("</table>");
		pw.println("<form class='acenter'  action='removeuser' method='post'><br>");
		pw.println("<input type='submit' value='Delete user'>");	

		pw.println("</form>");
		pw.println("</div>");
		pw.println("</body>");
		pw.println("</html>");

		}catch(Exception e){
			System.out.println(e);
		}
	}
	public void DeleteUser() throws Exception{
		try{
			String url = "jdbc:mysql://localhost:3306/library";
			String user = "root";
			String password = "preethi";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true&useSSL=false",user,password);
			
			Statement st = con.createStatement();
			
			
			String sql = "delete from student  where 2021-yearofjoin>4";


			
			st.executeUpdate(sql);
		}catch(Exception e){
			System.out.println(e);
		}
	}

}


